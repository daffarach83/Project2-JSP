/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

/**
 *
 * @author AKSEL
 */
public class Mahasiswa {
    
    private int nimID;
    private String nama;
    private String kelas;
    private String prodi;
    private String kelamin;
    
    public int getNimID() {
    return nimID;
    }
    public void setNimID(int nimID) {
    this.nimID = nimID;
    }
    public String getNama() {
    return nama;
    }
    public void setNama(String nama) {
    this.nama = nama;
    }
    public String getKelas() {
    return kelas;
    }
    public void setKelas(String kelas) {
    this.kelas = kelas;
    }
    public String getProdi() {
    return prodi;
    }
    public void setProdi(String prodi) {
    this.prodi = prodi;
    }
    public String getKelamin() {
    return kelamin;
    }
    public void setKelamin(String kelamin) {
    this.kelamin = kelamin;
    }
}
