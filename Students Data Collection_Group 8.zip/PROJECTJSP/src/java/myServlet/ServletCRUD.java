/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.MahasiswaDao;
import Bean.Mahasiswa;
import javax.servlet.RequestDispatcher;

public class ServletCRUD extends HttpServlet {
    private static String Insert = "/addmahasiswa.jsp";
    private static String Edit = "/edit.jsp";
    private static String ListMahasiswa = "/listMahasiswa.jsp";
    
    private MahasiswaDao mahasiswaDao;
    public ServletCRUD (){
        super();
        mahasiswaDao = new MahasiswaDao();
    }
    
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    String redirectURL="";
    String nim = request.getParameter("nim");
    System.out.println("Nim"+nim);
    String act=request.getParameter("action");
    
    if(nim != null && act.equalsIgnoreCase("insert")){
        int id = Integer.parseInt(nim);
        Mahasiswa mahasiswa = new Mahasiswa();
        mahasiswa.setNimID(id);

        mahasiswa.setNama(request.getParameter("nama"));
        mahasiswa.setKelas (request.getParameter("kelas"));
        mahasiswa.setProdi(request.getParameter("prodi"));
        mahasiswa.setKelamin(request.getParameter("kelamin"));
    
        mahasiswaDao.addMahasiswa(mahasiswa);
        redirectURL = ListMahasiswa;
        request.setAttribute("mahasiswa", mahasiswaDao.retrieveMahasiswa());
        System.out.println("Record Added Successfully");
    
    } else if(act.equalsIgnoreCase("delete")) {
        int id = Integer.parseInt(nim);
        mahasiswaDao.deleteNimById(id);
        redirectURL = ListMahasiswa;
        request.setAttribute("mahasiswa", mahasiswaDao.retrieveMahasiswa());
        System.out.println("Record Deleted Successfully");

    } else if(act.equalsIgnoreCase("retrieve")){
        redirectURL = ListMahasiswa;
        request.setAttribute("mahasiswa", mahasiswaDao.retrieveMahasiswa());

    }else if (act.equalsIgnoreCase("editform")){
        redirectURL = Edit;

    } else if(act.equalsIgnoreCase("update")){

        System.out.println("Im Here" +nim);
        int id = Integer.parseInt(nim);
        Mahasiswa mahasiswa = new Mahasiswa();
        mahasiswa.setNimID(id);
        mahasiswa.setNama(request.getParameter("nama"));
        mahasiswa.setKelas (request.getParameter("kelas"));
        mahasiswa.setProdi(request.getParameter("prodi"));
        mahasiswa.setKelamin(request.getParameter("kelamin"));

        mahasiswaDao.editMahasiswa(mahasiswa);
        request.setAttribute("mahasiswa", mahasiswa);
        redirectURL = ListMahasiswa;
        System.out.println("Record updated Successfully");

    } else {
        redirectURL= Insert;
    }
    
    RequestDispatcher rd = request.getRequestDispatcher(redirectURL);
    rd.forward(request, response);
}

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
    return "Short description";
    }// </editor-fold>
}