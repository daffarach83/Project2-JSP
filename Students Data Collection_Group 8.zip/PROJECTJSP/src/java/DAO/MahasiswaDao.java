/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import Bean.Mahasiswa;
import java.util.logging.Level;
import java.util.logging.Logger;
import myUtil.ConnectionDB;
public class MahasiswaDao {
    
private final Connection conn;
public MahasiswaDao(){
conn = ConnectionDB.getConnectionDB();
}

public void addMahasiswa(Mahasiswa mahasiswa){
try {
    String SQLInsert ="INSERT INTO mahasiswa(nim, nama, kelas, prodi, kelamin) values (?, ?, ?, ?, ?)";
    PreparedStatement prSt = conn.prepareStatement(SQLInsert);
    prSt.setInt(1, mahasiswa.getNimID());
    prSt.setString(2, mahasiswa.getNama());
    prSt.setString(3, mahasiswa.getKelas());
    prSt.setString(4, mahasiswa.getProdi());
    prSt.setString(5, mahasiswa.getKelamin());
    prSt.executeUpdate();
    } catch (SQLException ex) {
System.out.println(ex.getMessage());
    }
}

public void deleteNimById(int nimID){
try {
    String deleteQuery="delete from mahasiswa where nim=?";
    PreparedStatement prSt = conn.prepareStatement(deleteQuery);
    prSt.setInt(1, nimID);
    prSt.executeUpdate();
    } catch (SQLException ex) {
    System.out.println(ex.getMessage());
    }
}

public Mahasiswa findMahasiswaById(int nimID){
Mahasiswa nim = new Mahasiswa();
try {
String deleteQuery="select * from mahasiswa where nim=?";
PreparedStatement prSt = conn.prepareStatement(deleteQuery);
prSt.setInt(1, nimID);
ResultSet rs = prSt.executeQuery();
while(rs.next()){
nim.setNimID(nimID);
nim.setNama(rs.getString(2));
nim.setKelas(rs.getString(3));
nim.setProdi(rs.getString(4));
nim.setKelamin(rs.getString(5));

}
} catch (SQLException ex) {
System.out.println(ex.getMessage());
}
return nim;
}

public void editMahasiswa(Mahasiswa mahasiswa){
try {
    String editQuery="update mahasiswa set nama=?, kelas=?, prodi=?, kelamin=? where nim=?";
    PreparedStatement prSt = conn.prepareStatement(editQuery);
    prSt.setString(1, mahasiswa.getNama());
    prSt.setString(2, mahasiswa.getKelas());
    prSt.setString(3, mahasiswa.getProdi());
    prSt.setString(4, mahasiswa.getKelamin());
    prSt.setInt(5, mahasiswa.getNimID());
    prSt.executeUpdate();
    } catch (SQLException ex) {
    System.out.println(ex.getMessage());
    }
}

public List retrieveMahasiswa(){
List smahasiswa = new ArrayList();
try {
    String retrieveQuery = "select * from mahasiswa";
    Statement st = conn.createStatement();
    ResultSet rs = st.executeQuery(retrieveQuery);
    while(rs.next()){
    Mahasiswa mahasiswa = new Mahasiswa();
    mahasiswa.setNimID(rs.getInt(1));
    mahasiswa.setNama(rs.getString(2));
    mahasiswa.setKelas(rs.getString(3));
    mahasiswa.setProdi(rs.getString(4));
    mahasiswa.setKelamin(rs.getString(5));
    smahasiswa.add(mahasiswa);
    }
    } catch (SQLException ex) {
    Logger.getLogger(MahasiswaDao.class.getName()).log(Level.SEVERE, null, ex);
    }
    return smahasiswa;
    }
}